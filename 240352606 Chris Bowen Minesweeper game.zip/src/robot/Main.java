package robot;
//Import scanner
import java.util.Scanner;

public class Main {
		
	public static void main(String[] args) {
		
		//boolean variable to close do...while loop once bomb is located
		boolean winner = false;
		
		//Create Robot object
				Robot r = new Robot();
		        
		//Make object for scanner
				Scanner sc = new Scanner(System.in);
				
		//Initial menu output to instruct user what they must do		
				System.out.println("MENU:");	
				System.out.println("1. Move up!");
				System.out.println("2. Move down!");
				System.out.println("3. Move left!");
				System.out.println("4. Move right!");
				System.out.println("Your starting location is: (" + r.getX() +  ", " + r.getY() + ")");
				System.out.println("Can you locate the mine?");
				System.out.print("Please enter your choice (1-4): ");
			
	//while loop for robot location
		while (winner == false) {
	//take in object info for user input
		int option = sc.nextInt();
		
	//Print menu after each user input with space at start and end of menu to allow for better readability
		System.out.println();
		System.out.println("MENU:");	
		System.out.println("1. Move up!");
		System.out.println("2. Move down!");
		System.out.println("3. Move left!");
		System.out.println("4. Move right!");
		System.out.println();		
	//Switch statement to react to user inputs (in place of if else statement) - default reacts to anything outside of options 1-4
		switch (option) {
		case 1: r.moveUp(1);
			System.out.println("(" + r.getX() + ", " + r.getY() + ")");
			System.out.print("Please enter your choice (1-4): ");
			break;
		case 2: 
			r.moveDown(1);
			System.out.println("(" + r.getX() + ", " + r.getY() + ")");
			System.out.print("Please enter your choice (1-4): ");
			break;
		case 3:
			r.moveLeft(1);
			System.out.println("(" + r.getX() + ", " + r.getY() + ")");
			System.out.print("Please enter your choice (1-4): ");
			break;
		case 4:
			r.moveRight(1);
			System.out.println("(" + r.getX() + ", " + r.getY() + ")");
			System.out.print("Please enter your choice (1-4): ");
		default: 
			System.out.print("ERROR!!! ERROR!!! Invalid command code please use 1-4");
	    }	
		
	// if statement to check if the robot has found the mine and close the scanner (user input)	
		if (r.getX() == r.getA() && r.getY() == r.getB()) {
			System.out.println();
			System.out.println("BOOOOOOOOOOOOOOOM!!! Congratulations you found the mine! You win!!!");
			sc.close();
			System.exit(0);
			winner = true;
     
	     }
    }
 }
}
		
		

