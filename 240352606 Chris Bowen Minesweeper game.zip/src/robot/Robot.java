package robot;



public class Robot {
// setting variables - x & y for robot and a & b for the bomb		
	private int x = 0;
	private int y = 0;	
	private int a;
	private int b;
	
// setting the bombs position using math.random to select a random number * 4 limits it a number between 0 and 4. (int) sets it to a integer rather than a double
	public Robot() {
		int bombX = (int)(Math.random() * 5);
		int bombY = (int)(Math.random() * 5);
		a = bombX;
		b = bombY;
	}
	
// method to return the value of a to main	
	public int getA() {
		return a;
	}
	
// method to return the value of b to main	
	public int getB() {
		return b;
	}
	
// method to return the value of x to main		
	public int getX() {
		return x;
	}
	
// method to return the value of y to main		
	public int getY() {
		return y;
	}
	
	//Method for up movement of the robot
	public boolean moveUp(int distance) {
	  //Check to see if the movement distance is equal to or above a 1 it's a valid move
		if (distance >= 1) { 
				    
		 //check to see if movement will take the robot outside of the grid - if it will then return false and error message
		    if (y - distance < 0) {
			  System.out.print("ERROR!!! ERROR!!!, Unable to move any further up! Current location: ");
			return false;
		  } else { 
		//If check passed to see if robot will stay within grid then allow movement equal to inputed distance - in this case 1
			  y -= distance;
	   }
	  }
	//after check has been passed and y has been changed by the previous line of code we now pass a String to print and return a boolean of true
	  System.out.print("BEEP BOOP moving up! New location: ");
	  return true;
    }
	
//Method for down movement of the robot
	public boolean moveDown(int distance) {
	//Check to see if the movement distance is equal to or above a 1 it's a valid move
		if (distance >= 1) {
	
		//check to see if movement will take the robot outside of the grid - if it will then return false and error message
		  if (y + distance > 4) {
			  System.out.print("ERROR!!! ERROR!!!, Unable to move any further down! Current location: ");
			  return false;
		  } else {
		//If check passed to see if robot will stay within grid then allow movement equal to inputed distance 
			  y += distance;
		}
	  }
	//after check has been passed and y has been changed by the previous line of code we now pass a String to print and return a boolean of true
		System.out.print("BEEP BOOP moving down! New location: ");
		return true;
	}
	
//Method for left movement of the robot
	public boolean moveLeft(int distance) {
	//Check to see if the movement distance is equal to or above a 1 it's a valid move
		if (distance >= 1) {
	
	//check to see if movement will take the robot outside of the grid - if it will then return false and error message
   		if (x - distance < 0) {
   			System.out.print("ERROR!!! ERROR!!!, Unable to move any further left! Current location: ");
   			return false;
   		} else {
   	//If check passed to see if robot will stay within grid then allow movement equal to inputed distance 
   			x -= distance; 
   		}
	 }
	//after check has been passed and y has been changed by the previous line of code we now pass a String to print and return a boolean of true
		System.out.print("BEEP BOOP moving left! New location: ");
	   return true;
	}
	
//Method for left movement of the robot
	public boolean moveRight(int distance) {
	//Check to see if the movement distance is equal to or above a 1 it's a valid move
		if (distance >= 1) {
	
	//check to see if movement will take the robot outside of the grid - if it will then return false and error message
	      if (x + distance > 4) {
	    	  System.out.print("ERROR!!! ERROR!!!, Unable to move any further right! Current location: ");
	    	  return false;
	    } 
	    else {
	//If check passed to see if robot will stay within grid then allow movement equal to inputed distance
			x += distance; 
		}
	  }
  //after check has been passed and y has been changed by the previous line of code we now pass a String to print and return a boolean of true
		System.out.print("BEEP BOOP moving right! New location: ");
		return true;
	} 
	
	
}

